from setuptools import setup
from setuptools.command.install import install
import os
import subprocess

class CustomInstall(install):
    def run(self):
        install.run(self)
        subprocess.call(["/bin/bash", "install.sh"])

setup(
    name='weekdatemac',
    version='1.0.0',
    packages=['weekdatemac'],
    cmdclass={'install': CustomInstall},
    install_requires=[],
)
